package com.example.hereforu.form

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.RatingBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.hereforu.R
import com.example.hereforu.models.AnnouncementShowcase
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.getValue
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_user_profile.*
import kotlinx.android.synthetic.main.fragment_home.*
import kotlinx.android.synthetic.main.fragment_profilo.*
import kotlinx.android.synthetic.main.fragment_profilo.NameProfile
import java.text.SimpleDateFormat
import java.util.*

class AnnouncementActivity : AppCompatActivity() {
    public var announcement: AnnouncementShowcase? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_home)

        announcement = this.intent.getSerializableExtra("Announcement") as AnnouncementShowcase
        var textView: TextView = findViewById(R.id.announcementCourse)
        textView.text = announcement!!.nome
        textView= findViewById(R.id.AnnuncioCampo)
        textView.text = announcement!!.campo
        /*textView = findViewById(R.id.announcementRating)

        textView.text = announcement!!.sum */
        var ratingBar: RatingBar = findViewById(R.id.announcementRating)
        ratingBar.rating = announcement!!.sum.toFloat()
        textView = findViewById(R.id.announcementPubDate)
        textView.text = announcement!!.pubDate
        var time= announcement!!.data.toLong()
        textView = findViewById(R.id.announcementGrade)

        val simpleDateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm")
        val dateString = simpleDateFormat.format(time)
        Toast.makeText(this, "DATA:"+dateString, Toast.LENGTH_LONG)
            .show()
        Log.d("TAG","DATA:"+dateString)
        textView.text = dateString
        textView = findViewById(R.id.announcementProfessor)
        textView.text = announcement!!.news
        textView = findViewById(R.id.announcementDescription)
        textView.text = announcement!!.description

        var uid = announcement!!.uid
        val db = FirebaseDatabase.getInstance().reference
        val uidRef = db.child("users").child(uid.toString())
        var nomemedico: String = "";
        var cognomemedico:String="";
        var srcImageProfile: String = "";
        MappaStudio.setOnClickListener {
            val activityIntent = Intent(this, MapsActivity::class.java)
            startActivity(activityIntent)
            finish()
        }
        val valueEventListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                nomemedico = snapshot.child("name").getValue<String>().toString()
                Log.d("TAG","NOME"+nomemedico)
                cognomemedico=snapshot.child("cognome").getValue<String>().toString()
                Log.d("TAG","COGNOME"+cognomemedico)
                textView = findViewById(R.id.announcementProfileName)
                textView.text = nomemedico+" "+cognomemedico
                srcImageProfile = snapshot.child("profileImagePath").getValue<String>().toString()
                Log.d("TAG","FOTO"+srcImageProfile)
                Picasso.with(this@AnnouncementActivity).load(srcImageProfile).into(announcementImageView)

            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.d("TAG", databaseError.getMessage())
            }
        }

        uidRef.addListenerForSingleValueEvent(valueEventListener)



    }






    /*
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)

        if (savedInstanceState == null) { // initial transaction should be wrapped like this
            Log.e("bug-hunting","begin transaction first access")
            val announcementFragment = AnnouncementFragment()
            supportFragmentManager.beginTransaction()
                .replace(R.id.announcementFragmentContainer, announcementFragment, "profileView")
                .addToBackStack("first")
                .commit()
        }
        announcement = this.intent.getSerializableExtra("Announcement") as AnnouncementShowcase
    }

    override fun onBackPressed() {
        if (supportFragmentManager.backStackEntryCount == 1) {
            finish()
        } else {
            super.onBackPressed()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return super.onSupportNavigateUp()
    }

    public fun loadFragment(fragment: Fragment){
        supportFragmentManager.beginTransaction().replace(R.id.announcementFragmentContainer, fragment).addToBackStack("second").commit()
    }

    public fun goBack(){

        while(supportFragmentManager.backStackEntryCount>0){
            supportFragmentManager.popBackStackImmediate()
        }

        val profileFragment = AnnouncementFragment()
        supportFragmentManager.beginTransaction()
            .replace(R.id.announcementFragmentContainer, profileFragment, "announcementView")
            .addToBackStack("first")
            .commit()
    } */
    }
