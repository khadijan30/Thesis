package com.example.hereforu.form

//per ora inutile

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.example.hereforu.models.Profile

class MainActivity : AppCompatActivity() {
    public var profile: Profile? = null
    public lateinit var headerNameTextView: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}