package com.example.hereforu.form

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import com.example.hereforu.models.AnnouncementShowcase
import com.example.hereforu.R
import com.google.firebase.database.*
import com.google.firebase.database.ktx.getValue
import java.text.SimpleDateFormat
import java.util.*
import kotlin.Comparator
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

//non finita, per ora inutile
class PopUpListAnnouncementActivity:AppCompatActivity() {
    private var announcementList=ArrayList<AnnouncementShowcase>()
    private lateinit var listView: ListView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_listview_announcement)
        listView = findViewById(R.id.popUpAnnouncementListView)
        listView.setOnItemClickListener { parent, view, position, id ->
            val intent = Intent(this, AnnouncementActivity::class.java)
            intent.putExtra("Announcement", announcementList[position])
            startActivityForResult(intent, 0)
        }



        // definisco un array di stringhe
        val nameproducts = arrayOf<String>("Product1", "Product2", "Product3");


        // definisco un ArrayList

        var listp = prepareList();

        Log.d("TAG", "SIZELISTP:"+listp.size)


    }
    private fun prepareList(): ArrayList<AnnouncementShowcase> {
        val ref = FirebaseDatabase.getInstance().getReference("/announcements/")
        // val uid = this.intent.getStringExtra("uid")!!
        //val uid =ref.child("xOEVRCMCU5WZNd42584w5LIoxsJ2")
        Log.d("TAG", "Entra nel Preparelist")
        //val uidRef = ref.child()
        var userUid: String?
        var announcmentid: String?
        var campo: String?
        var data: String?
        var news: String?
        var description: String?
        var timestamp: String?
        var nome: String?
        var score: String?
        var counter: String?
        var prova:Int
        var list= arrayListOf<AnnouncementShowcase>()
      //  announcementList.clear()
        //list.clear()



        val valueEventListener = object : ValueEventListener {

            override fun onDataChange(dataSnapshot: DataSnapshot) {


                //val profileRef = ref.child(uid.toString()).ref



                var y :Int
                y=0;

                for (ds in dataSnapshot.children) {

                    y += 1;
                    Log.d("TAG", ds.toString())



                    //non faccio vedere gli annunci di chi scrive
                    //if (ds.ref != profileRef) continue
                    for (dsChild in ds.children) {
                        Log.d("TAG", "Entra nel secondo For")
                        Log.d("TAG", dsChild.toString())


                        //if(dsChild.child("uid").value.toString()==uid) break


                        announcmentid = dsChild.child("announcementId").getValue<String>().toString()
                        Log.d("TAG", announcmentid.toString())
                        campo = dsChild.child("campo").getValue<String>().toString()
                        Log.d("TAG", "CAMPO"+campo.toString())
                        counter = dsChild.child("counter").value.toString()
                        Log.d("TAG", "COUNTER"+counter.toString())
                        //prova=counter.toInt()
                        data = dsChild.child("data").value.toString()
                        Log.d("TAG", "DATA:"+data.toString())
                        description = dsChild.child("description").value.toString()
                        Log.d("TAG", "DESCRIPTION"+description.toString())
                        news = dsChild.child("news").value.toString()
                        Log.d("TAG", "NEWS"+news.toString())
                        nome = dsChild.child("nome").value.toString()
                        Log.d("TAG", "NOME"+nome.toString())
                        timestamp = dsChild.child("pubDate").value.toString()
                        Log.d("TAG", "TIMESTAMP"+timestamp.toString())
                        score = dsChild.child("score").value.toString()
                        Log.d("TAG", "SCORE:"+score.toString())
                        userUid = dsChild.child("uid").value.toString()
                        Log.d("TAG", "USERUID"+userUid.toString())


                        var element= AnnouncementShowcase(
                            userUid!!,
                            announcmentid!!,
                            nome!!,
                            campo!!,
                            data!!,
                            news!!,
                            description!!,
                            timestamp!!,
                            counter!!,
                            score!!,
                        )
                            announcementList.add(element)
                        Log.d("TAG", "assegnazioni fatte")
                    }

                    Log.d("TAG", "SIZE"+announcementList.size)

                }


                loadList()

            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.d("TAG", databaseError.getMessage())
            }

        }
        ref.addListenerForSingleValueEvent (valueEventListener)
        /*
        var mylist: ListView
        // recupero la lista dal layout
        mylist = findViewById(R.id.popUpAnnouncementListView);

        // creo e istruisco l'adattatoremylist
        val adapter = ArrayAdapter<AnnouncementShowcase>(this, android.R.layout.simple_list_item_1, announcementList);
        mylist.setAdapter(adapter); */
        return announcementList
        }

    fun loadList(){
        Log.d("TAG", "SIZEINLOADLIST:"+announcementList.size)
        // create a List of Map<String, ?> objects
        val data = ArrayList<HashMap<String, String>>()

        try {
            announcementList.sortWith(Comparator { x, y ->
                compareValues(y.pubDate, x.pubDate)
            })
        }catch(e:Error){
            Log.d("TAG", "Vediamo se fa errore:")
        }

        Locale.setDefault(Locale.ITALIAN)
        val sdf = SimpleDateFormat("dd MMMM yyyy - HH:mm:ss")
        var netDate: Date

        for (item in announcementList) {

            val map = HashMap<String, String>()
            map["name"] = item.nome
            map["course"] = item.campo

            if(item.counter.toInt() > 2)
                map["score"] = item.sum.toString()
            else
                map["score"] = "0"

            try {
                netDate = Date(item.pubDate.toLong())
                item.pubDate = sdf.format(netDate)
            }catch (e: Exception){
                Log.d("TAG", "ERRORE:")
            }


            map["pubDate"] = "pubblicato: ${item.pubDate}"
            data.add(map)
        }
        Log.d("TAG", "Vediamo se è passato nel for TRUE:"+data)
        // create the resource, from, and to variables
        val resource: Int = R.layout.showcase_listview_item

        val from = arrayOf("name","course","pubDate", "score")
        val to = intArrayOf(R.id.mostranome,R.id.mostracampo,  R.id.mostrapubdata, R.id.feedBackShowcaseItem)
        // create and set the adapter
        val adapter = SimpleAdapter(applicationContext, data, resource, from, to)

        adapter.viewBinder = MyBinder()
        listView.adapter = adapter

    }
    private class MyBinder: SimpleAdapter.ViewBinder{
        override fun setViewValue(view: View?, data: Any?, textRepresentation: String?): Boolean {
            Log.d("TAG", view!!.id.toString()+R.id.feedBackShowcaseItem.toString())
            if(view!!.id == R.id.feedBackShowcaseItem){

                val stringval = data.toString()
                val ratingValue = stringval.toFloat()
                Log.d("TAG", "Vediamo se è passato nel for TRUE:"+ratingValue)
                val ratingBar: RatingBar = view as RatingBar
                ratingBar.rating = ratingValue
                return true
            }
            Log.d("TAG", "Vediamo se è passato nel for:")
            return false
        }
    }
    }


    // inietto i dati


     /*
   private var announcementList = ArrayList<AnnouncementShowcase>()
   private lateinit var uid: String
   private lateinit var listView: ListView



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_listview_announcement)
        uid = this.intent.getStringExtra("uid")!!
        val isMy = this.intent.getBooleanExtra("isMy", false)
        listView = findViewById(R.id.popUpAnnouncementListView)
        listView.setOnItemClickListener { parent, view, position, id ->
                val stringToCopy = announcementList[position].campo
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("campo", stringToCopy)
                clipboard.setPrimaryClip(clip)
                Toast.makeText(
                    this@PopUpListAnnouncementActivity,
                    "Testo copiato negli appunti",
                    Toast.LENGTH_SHORT
                ).show()
            }

        loadView()
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 0 && resultCode == Activity.RESULT_OK)
            loadView()
    }

    private fun loadView() {
        val ref = FirebaseDatabase.getInstance().getReference("/announcements/")
        ref.addListenerForSingleValueEvent(prepareList(ref, uid))
    }

    private fun prepareList(ref: DatabaseReference, uid: String): ValueEventListener {
        var userUid: String?
        var listUid: String?
        var campo: String?
        var data: String?
        var news: String?
        var description: String?
        var timestamp: String?
        var nome: String?
        var score: Float
        var counter: Int

        announcementList.clear()

        return object : ValueEventListener {
            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val profileRef = ref.child(uid).ref

                for (ds in dataSnapshot.children) {
                    //non faccio vedere gli annunci di chi scrive
                    if (ds.ref != profileRef) continue
                    for (dsChild in ds.children) {
                        //if(dsChild.child("uid").value.toString()==uid) break
                        userUid = dsChild.child("uid").value.toString()
                        listUid = dsChild.child("announcementId").value.toString()
                        nome = dsChild.child("nome").value.toString()
                        campo = dsChild.child("campo").value.toString()
                        data = dsChild.child("data").value.toString()
                        news = dsChild.child("news").value.toString()
                        description = dsChild.child("description").value.toString()
                        timestamp = dsChild.child("pubDate").value.toString()
                        score = dsChild.child("score").value.toString().toFloat()
                        counter = dsChild.child("counter").value.toString().toInt()


                        announcementList.add(AnnouncementShowcase(userUid!!, listUid!!,nome!!, campo!!, data!!, news!!, description!!,timestamp!!, counter, score))
                    }
                }
                loadList()
            }
        }
    }
    fun loadList(){
        // create a List of Map<String, ?> objects
        val data = ArrayList<HashMap<String, String>>()

        try {
            announcementList.sortWith(Comparator { x, y ->
                compareValues(y.pubDate, x.pubDate)
            })
        }catch(e:Error){
        }
        Locale.setDefault(Locale.ITALIAN)
        val sdf = SimpleDateFormat("dd MMMM yyyy - HH:mm:ss")
        var netDate: Date

        for (item in announcementList) {
            val map = HashMap<String, String>()
            map["name"] = item.nome
            map["campo"] = item.campo
            map["data"] = item.data

            if(item.counter > 2)
                map["score"] = item.sum.toString()
            else
                map["score"] = "0"

            try {
                netDate = Date(item.pubDate.toLong())
                item.pubDate = sdf.format(netDate)
            }catch (e: Exception){
            }

            map["pubDate"] = "pubblicato: ${item.pubDate}"
            data.add(map)
        }
        // create the resource, from, and to variables
        val resource: Int = R.layout.showcase_listview_item
        val from = arrayOf("nome","campo", "data","pubDate", "score")
        val to = intArrayOf(R.id.mostranome, R.id.mostracampo, R.id.mostraData, R.id.mostrapubdata, R.id.feedBackShowcaseItem)
        // create and set the adapter
        val adapter = SimpleAdapter(applicationContext, data, resource, from, to)
        adapter.viewBinder = MyBinder()
        listView.adapter = adapter
    }

    private class MyBinder: SimpleAdapter.ViewBinder{
        override fun setViewValue(view: View?, data: Any?, textRepresentation: String?): Boolean {
            if(view!!.id == R.id.feedBackShowcaseItem){
                val stringval = data.toString()
                val ratingValue = stringval.toFloat()
                val ratingBar: RatingBar = view as RatingBar
                ratingBar.rating = ratingValue
                return true
            }
            return false
        }
    }
}
*/

