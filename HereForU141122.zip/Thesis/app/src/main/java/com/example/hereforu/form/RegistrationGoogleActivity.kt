package com.example.hereforu.form

class RegistrationGoogleActivity {
}