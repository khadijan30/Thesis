package com.example.hereforu.form

class VerifyEmailActivity {
}