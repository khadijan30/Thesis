package com.example.hereforu.models

import java.io.Serializable

class AnnouncementShowcase(val uid: String, val listUid:String, val nome: String, val campo:String, val data: String, val news: String, val description: String, var pubDate: String, var counter: String, var sum: String): Serializable{
    constructor() : this("", "","","","","","","", "0", "0")
}