package com.example.hereforu.models

class CitizenUser(val uid:String,val name:String,val cognome:String,val email:String, val profileImagePath:String, val identificativo:String){

}