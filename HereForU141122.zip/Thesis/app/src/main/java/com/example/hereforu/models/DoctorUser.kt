package com.example.hereforu.models



 class DoctorUser (
     val uid: String,
     val name: String,
     val cognome: String,
     val email: String,
     val numerOrdine:String,
     val profileImagePath: String,
     val identificativo:String)
 {

 }