package com.example.hereforu.models
import java.io.Serializable

//inutile per ora

class Profile(private var uid: String, private var profileImageUrl: String, private var name: String, private var telegram: String, private var degree:String, private var department:String, private var isGoogle: Int) :Serializable{

    constructor(): this("","","","","","", 0)

    /*public fun updateProfile(profileImageUrl: String, name: String, telegram: String, degree:String, department:String, isGoogle: Int){
        this.profileImageUrl = profileImageUrl
        this.name = name
        this.telegram = telegram
        this.degree = degree
        this.department = department
        this.isGoogle = isGoogle
    } */

    public fun updateProfileFromProfile(profile: Profile){
        this.profileImageUrl = profile.getProfileImageUrl()
        this.name = profile.getName()
        this.telegram = profile.getTelegram()
        this.degree = profile.getDegree()
        this.department = profile.getDepartment()
    }

    /*public fun getUserFromProfile(): User{
        return User(uid, name, profileImageUrl, telegram, department, degree, isGoogle)
    }*/

    public fun getUserId(): String {
        return uid
    }

    public fun getProfileImageUrl(): String {
        return profileImageUrl
    }

    public fun setProfileImageUrl(Url: String) {
        this.profileImageUrl = Url
    }

    public fun getName(): String {
        return name
    }

    public fun setName(name: String) {
        this.name = name
    }

    public fun getTelegram(): String {
        return telegram
    }

    public fun setTelegram(telegram: String) {
        this.telegram = telegram
    }

    public fun getDegree(): String {
        return degree
    }

    public fun setDegree(degree: String) {
        this.degree = degree
    }

    public fun getDepartment(): String {
        return department
    }

    public fun setDepartment(department: String){
        this.department = department
    }

    public fun isGoogle() : Int{
        return isGoogle
    }
}